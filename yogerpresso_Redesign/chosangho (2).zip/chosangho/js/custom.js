$(document).ready(function(){

  $('.banner').each(function() {
      var $container=$(this),                                
                  $slideGroup=$container.find('.slides'),   
                  $slides=$slideGroup.find('.slide>a'),                
                  $nav=$container.find('.banner-btn'),             
                  $indicator=$container.find('.banner-indi'),
                  slideCount=4, 
                  // slideCount=$slides.length,          
                  currentIndex=0,            
                  duration=500,             
                  interval=2000, 
                  timer;


        function goToSlide (index) {
            // 슬라이드 그룹을 대상 위치에 맞게 이동
            $slideGroup.animate({ left: (-100 * index) + '%' }, duration);
            // 현재 슬라이드의 인덱스를 덮어쓰기
            currentIndex = index;
            // 탐색 및 표시 상태를 업데이트
            updateNav();
        }


        // 슬라이드의 상태에 따라 탐색 및 표시를 업데이트하는 함수
        function updateNav(){
           
            // 현재 슬라이드의 표시를 해제
            $indicator.find('a').removeClass('on')
            .eq(currentIndex).addClass('on');
            
        }   //updateNav(){

        // 타이머를 시작하는 함수
        function startTimer(){
            // 변수 interval에서 설정 한 시간이 경과 할 때마다 작업을 수행
            timer=setInterval(function(){
                // 현재 슬라이드의 인덱스에 따라 다음 표시 할 슬라이드의 결정
                // 만약 마지막 슬라이드이라면 첫 번째 슬라이드에
                var nextIndex=(currentIndex+1)%slideCount;
                goToSlide(nextIndex);
            }, interval);
        }   //startTimer(){

        // 타이머를 중지있는 함수
        function stopTimer(){
            clearInterval(timer);
        }   //stopTimer(){



    // 인벤토리 등록
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

        // 네비게이션 링크를 클릭하면 해당 슬라이드를 표시
        $nav.on('click', 'a', function(event){
            event.preventDefault();
            if($(this).hasClass('prev')) {
              if(currentIndex==0){
                goToSlide(3);
              }else{
                goToSlide(currentIndex-1);
              }
            } else if($(this).hasClass('next')){
              if(currentIndex==3){
                goToSlide(0);
              }else{
                goToSlide(currentIndex+1);
              }
            }
        }); //$nav.on('click', 'a', function(event){

        // 인디게이터의 링크를 클릭하면 해당 슬라이드를 표시
        $indicator.on('click', 'a', function(event) {
            event.preventDefault();
            if (!$(this).hasClass('on')) {
                goToSlide($(this).index());
            }
        }); //$indicator.on('click', 'a',

        // 마우스오버를 하면 타이머를 정지 그렇지 않으면 시작
        $container.on({
            mouseenter: stopTimer,
            mouseleave: startTimer
        }); // $container.on({
    // 슬라이드 쇼 시작
    // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        // 첫 번째 슬라이드를 표시
        goToSlide(currentIndex);
        // 타이머를 시작
        startTimer();
    });




// **********************************************************

// 	//배너 슬라이드
// 	var current = 0;
//     var abcd;
//     //slide함수 선언, eq(인덱스) 인자값을 받아옴
//     // *******************************************
//     // eq->i
//     function slide(i){
//     // function slide(eq){
//         //slide 이미지들을 각 너비의 100*eq(인덱스 값)만큼 1000ms동안 이동
//         // *********************************
//         $(".slides").animate({left:(-100*i)+'%'},1000);  
//         // $(".slides").animate({"left":(-100 * i) + "%"},1000);        
//         //current(현재 위치)에 eq(인덱스)값 대입.
//         current = i;
//         //인디케이터들에게서 on 클래스제거
//         $(".banner-indi>a").removeClass("on");
//         $(".banner-indi>a").eq(current).addClass("on");
//     }

//       //start함수 선언
//       function start(){
//         //변수 abcd에 슬라이드 간격 이벤트 선언
//         var abcd = setInterval(function(){
//         //current + 1 = 현재 슬라이드의 다음 인덱스 값,
//         //4 = 총 슬라이드의 갯수.
//         //다음 인덱스 값을 총 슬라이드 갯수로 나누어 그 나머지 값을 nextEq에 대입함으로써
//         //current 값이 무한으로 증가하더라도 4 cycle에서 벗어날 수 없다.
//         var nextEq = (current + 1) % 4; 
//         // 계산식 nextEq를 함수 slide()의 인자값으로 보냄으로써 무한 슬라이드 완성 
//         slide(nextEq);
//         // ****************************
//         }, 4000);
//         // }, 5000);
// 		  }
//       //자동 슬라이드 시작
//       start();



//       //배너 위에 마우스 호버시 자동 슬라이드 해제

//       $(".banner").mouseenter(function(){
//         clearInterval(abcd);
//       });

//       //배너 위에서 마우스 호버 해제시 자동 슬라이드 시작
//         $(".banner").mouseleave(function(){
       
//         start();
//       });
      
      

//       //슬라이드 버튼 클릭시
//       $(".banner-btn>a").click(function(){
//       	event.preventDefault();                //본래 a태그의 이벤트 제거
//       	$(".slides").stop().animate();  //애니메이션 멈춤
//         if ($(this).hasClass("prev")) {        //만약 누른 버튼이 이전 버튼이라면(prev)
//           // slide(current);
//           if (current<=0) {                    //만약 현재 슬라이드가 첫번째거나 그 이하라면
//             slide(3);                          //슬라이드 3으로 이동
//           } else {                             //그렇지않다면
//             slide(current-1);                  //이전 이미지로 이동
//           }
//         } else if ($(this).hasClass("next")) {  
//           // slide(current);
//           if (current>=3) {
//             slide(0);
//           } else {
//             slide(current+1);
//           }
//         }
//       });


//       // $(".banner-indi>a").click(function(event){   //인디케이터 버튼 클릭시
//       // 	event.preventDefault();               
//       //   var clickedindi = $(this).index();    //클릭된 인디케이터의 인덱스값을 변수에 대입
//       //   slide(clickedindi);                   //그 값만큼 슬라이드        
//       // });


// });






// ************************************
      $("header").each(function(){

        var $window = $(window),
            $header = $(this),
            //헤더 복제
            $headerClone = $header.contents().clone(),
            //헤더 복제 컨테이너
            $headerCloneContainer = $('<div class="header-clone"></div>'),
            //컨테이너를 나타나게할 위치
            threshold = 110;

        //컨테이너 헤더의 복제 삽입
        $headerCloneContainer.append($headerClone);
        //컨테이너를 body 마지막에 삽입
        $headerCloneContainer.appendTo("body");

        $window.on('scroll',function(){
          //현재 스크롤 위치가 목표 위치보다 낮으면 
          if ($window.scrollTop()>threshold)
            $headerCloneContainer.addClass('visible');
          else 
            $headerCloneContainer.removeClass('visible');
        });
      });

      //좌측 메뉴 호출 버튼
      var trigger = $(".trigger"),
          menu = $(".menu-wrap"),
          span = $("header span");
          // menu.height() = $(document).height();
          // ***************************
          var navHeight=$(window).height();
          // console.log(navHeight);
          $("header .menu-wrap").height(navHeight);

      $(trigger).on('click',function(e) {
        e.preventDefault();
        menu.stop().animate({"left":"0px"});
        $(span).addClass("visible"); 
      });

      $(span).on("click",function(e){
        e.preventDefault();
        menu.stop().animate({"left":"-100%"});
        $(this).removeClass("visible");
        $(".sub-menu").removeClass("on");
      });
        $(window).resize(function(){
          var w = $(window).width();
          if (w>320&& menu.is(':hidden')) {
            menu.removeAttr('style');
          }
        });

      //메뉴 li 버튼
      var mainMenu = $(".main-menu li");
      mainMenu.on("click",function(e){
        e.preventDefault();
        $(".sub-menu").removeClass("on");
        var subMenu = $(this).find(".sub-menu");
        subMenu.addClass("on");        
      });


});